== Comment installer les données d'exemple ? ==

1) Copier les dossiers : brands, projects, tmp, users du fichier .zip dans le dossier /web/uploads
2) Importer le fichier dev.littlebigjoe.com.sql pour installer les différentes tables et les données
3) Plusieurs comptes utilisateurs sont disponibles :
	- laurentbrieu@gmail.com / laurent => Compte utilisateur classique
	- admin@littlebigjoe.com / admin => Compte admin + compte utilisateur
	- pierrick@adentify.com / pierrick => Compte admin + compte utilisateur 
4) Enjoy !