SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


CREATE TABLE IF NOT EXISTS `brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `facebook_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `google_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_phone` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

INSERT INTO `brand` (`id`, `name`, `slug`, `logo`, `description`, `facebook_url`, `twitter_url`, `google_url`, `website_url`, `contact_name`, `contact_status`, `contact_phone`, `contact_email`) VALUES
(1, 'Nike', 'nike', 'uploads/brands/36e013f04276931c5b8e4081114c828179dec7a2.jpg', '&lt;p style="text-align:start"&gt;&lt;strong&gt;Nike&lt;/strong&gt; (&lt;a href="http://fr.wikipedia.org/wiki/Alphabet_phon%C3%A9tique_international" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="Alphabet phonétique international"&gt;[ˈnaɪk]&lt;/a&gt;&lt;sup&gt;&lt;a href="http://fr.wikipedia.org/wiki/Nike_(entreprise)#cite_note-1" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;"&gt;1&lt;/a&gt;&lt;/sup&gt;) est une entreprise &lt;a href="http://fr.wikipedia.org/wiki/%C3%89tats-Unis" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="États-Unis"&gt;américaine&lt;/a&gt; spécialisée dans les chaussures, les vêtements et le matériel de &lt;a href="http://fr.wikipedia.org/wiki/Sport" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="Sport"&gt;sport&lt;/a&gt;. Le nom est inspiré de la déesse grecque de la victoire &lt;a href="http://fr.wikipedia.org/wiki/Nik%C3%A9" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="Niké"&gt;Niké&lt;/a&gt;, déesse ailée capable de se déplacer à grande vitesse, dont la représentation la plus connue, une statue exposée au &lt;a href="http://fr.wikipedia.org/wiki/Mus%C3%A9e_du_Louvre" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="Musée du Louvre"&gt;Louvre&lt;/a&gt;, est la &lt;a href="http://fr.wikipedia.org/wiki/Victoire_de_Samothrace" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="Victoire de Samothrace"&gt;Victoire de Samothrace&lt;/a&gt;.&lt;/p&gt;\r\n\r\n&lt;p style="text-align:start"&gt;Nike a assuré sa notoriété par un logo simple et rapidement reconnaissable&amp;nbsp;: le &lt;em&gt;&lt;a href="http://fr.wikipedia.org/wiki/Swoosh" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="Swoosh"&gt;Swoosh&lt;/a&gt;&lt;/em&gt;, une virgule posée à l''envers et à l''horizontale&amp;nbsp;; il a été créé par Carolyn Davidson en 1971&lt;sup&gt;&lt;a href="http://fr.wikipedia.org/wiki/Nike_(entreprise)#cite_note-2" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;"&gt;2&lt;/a&gt;&lt;/sup&gt; comme une représentation stylisée de l''aile de la déesse.&lt;/p&gt;\r\n\r\n&lt;p style="text-align:start"&gt;Le siège de Nike est à &lt;a href="http://fr.wikipedia.org/wiki/Beaverton_(Oregon)" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="Beaverton (Oregon)"&gt;Beaverton&lt;/a&gt;, &lt;a href="http://fr.wikipedia.org/wiki/Oregon" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="Oregon"&gt;Oregon&lt;/a&gt;.&lt;/p&gt;', 'https://www.facebook.com/nike', 'https://twitter.com/Nike', 'https://plus.google.com/+nike', 'http://www.nike.com', 'John Doe', 'CEO', '55546679', 'ceo@nike.com'),
(2, 'Apple', 'apple', 'uploads/brands/43fc27a8dcb049df1278d67a65bded79987c55fd.gif', '&lt;p&gt;&lt;strong&gt;Apple&lt;/strong&gt; est une &lt;a href="http://fr.wikipedia.org/wiki/Entreprise" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-color: rgb(255, 255, 255); font-family: sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 19.1875px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-position: initial initial; background-repeat: initial initial;" title="Entreprise"&gt;entreprise&lt;/a&gt; multinationale &lt;a href="http://fr.wikipedia.org/wiki/%C3%89tats-Unis" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-color: rgb(255, 255, 255); font-family: sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 19.1875px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-position: initial initial; background-repeat: initial initial;" title="États-Unis"&gt;américaine&lt;/a&gt; qui conçoit et commercialise des produits &lt;a href="http://fr.wikipedia.org/wiki/%C3%89lectronique_grand_public" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-color: rgb(255, 255, 255); font-family: sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 19.1875px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-position: initial initial; background-repeat: initial initial;" title="Électronique grand public"&gt;électroniques grand public&lt;/a&gt;, des &lt;a href="http://fr.wikipedia.org/wiki/Ordinateur_personnel" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-color: rgb(255, 255, 255); font-family: sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 19.1875px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-position: initial initial; background-repeat: initial initial;" title="Ordinateur personnel"&gt;ordinateurs personnels&lt;/a&gt; et des &lt;a href="http://fr.wikipedia.org/wiki/Logiciel" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-color: rgb(255, 255, 255); font-family: sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 19.1875px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-position: initial initial; background-repeat: initial initial;" title="Logiciel"&gt;logiciels informatiques&lt;/a&gt;. Parmi les produits les plus connus de l''entreprise se trouvent les ordinateurs &lt;a href="http://fr.wikipedia.org/wiki/Macintosh" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-color: rgb(255, 255, 255); font-family: sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 19.1875px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-position: initial initial; background-repeat: initial initial;" title="Macintosh"&gt;Macintosh&lt;/a&gt;, l''&lt;a href="http://fr.wikipedia.org/wiki/IPod" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-color: rgb(255, 255, 255); font-family: sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 19.1875px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-position: initial initial; background-repeat: initial initial;" title="IPod"&gt;iPod&lt;/a&gt;, l''&lt;a href="http://fr.wikipedia.org/wiki/IPhone" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-color: rgb(255, 255, 255); font-family: sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 19.1875px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-position: initial initial; background-repeat: initial initial;" title="IPhone"&gt;iPhone&lt;/a&gt; et l''&lt;a href="http://fr.wikipedia.org/wiki/IPad" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-color: rgb(255, 255, 255); font-family: sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 19.1875px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-position: initial initial; background-repeat: initial initial;" title="IPad"&gt;iPad&lt;/a&gt;, le lecteur multimédia &lt;a href="http://fr.wikipedia.org/wiki/ITunes" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-color: rgb(255, 255, 255); font-family: sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 19.1875px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-position: initial initial; background-repeat: initial initial;" title="ITunes"&gt;iTunes&lt;/a&gt;, la suite bureautique &lt;a href="http://fr.wikipedia.org/wiki/IWork" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-color: rgb(255, 255, 255); font-family: sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 19.1875px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-position: initial initial; background-repeat: initial initial;" title="IWork"&gt;iWork&lt;/a&gt;, la suite multimédia &lt;a href="http://fr.wikipedia.org/wiki/ILife" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-color: rgb(255, 255, 255); font-family: sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 19.1875px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-position: initial initial; background-repeat: initial initial;" title="ILife"&gt;iLife&lt;/a&gt; ou des logiciels à destination des professionnels tels que &lt;a href="http://fr.wikipedia.org/wiki/Final_Cut_Pro" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-color: rgb(255, 255, 255); font-family: sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 19.1875px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-position: initial initial; background-repeat: initial initial;" title="Final Cut Pro"&gt;Final Cut Pro&lt;/a&gt; et &lt;a href="http://fr.wikipedia.org/wiki/Logic_Pro" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-color: rgb(255, 255, 255); font-family: sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 19.1875px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-position: initial initial; background-repeat: initial initial;" title="Logic Pro"&gt;Logic Pro&lt;/a&gt;. En 2011, l''entreprise emploie 60&amp;nbsp;400 employés&lt;sup&gt;&lt;a href="http://fr.wikipedia.org/wiki/Apple#cite_note-10-K-3" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;"&gt;3&lt;/a&gt;&lt;/sup&gt; pour un chiffre d''affaires annuel de 108,25 milliards de dollars&lt;sup&gt;&lt;a href="http://fr.wikipedia.org/wiki/Apple#cite_note-10-K-3" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;"&gt;3&lt;/a&gt;&lt;/sup&gt; et exploite 394 &lt;a href="http://fr.wikipedia.org/wiki/Apple_Store" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-color: rgb(255, 255, 255); font-family: sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 19.1875px; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-position: initial initial; background-repeat: initial initial;" title="Apple Store"&gt;Apple Stores&lt;/a&gt; répartis dans 13 pays&lt;sup&gt;&lt;a href="http://fr.wikipedia.org/wiki/Apple#cite_note-4" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;"&gt;4&lt;/a&gt;&lt;/sup&gt; &lt;sup&gt;&lt;a href="http://fr.wikipedia.org/wiki/Apple#cite_note-5" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;"&gt;5&lt;/a&gt;&lt;/sup&gt; et une boutique en ligne où sont vendus les appareils et logiciels d''Apple mais aussi de tiers.&lt;/p&gt;', NULL, NULL, NULL, 'http://www.apple.com/', 'Mike Tyson', 'Marketing director', '446791', 'marketing@apple.com'),
(3, 'Orange', 'orange', NULL, '&lt;p style="text-align:start"&gt;&lt;strong&gt;Orange&lt;/strong&gt;, anciennement &lt;strong&gt;&lt;a href="http://fr.wikipedia.org/wiki/France_T%C3%A9l%C3%A9com" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="France Télécom"&gt;France Télécom&lt;/a&gt;&lt;/strong&gt;&lt;sup&gt;&lt;a href="http://fr.wikipedia.org/wiki/Orange_(entreprise)#cite_note-3" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;"&gt;3&lt;/a&gt;&lt;/sup&gt;, est une entreprise &lt;a href="http://fr.wikipedia.org/wiki/France" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="France"&gt;française&lt;/a&gt; de &lt;a class="mw-redirect" href="http://fr.wikipedia.org/wiki/T%C3%A9l%C3%A9communication" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="Télécommunication"&gt;télécommunications&lt;/a&gt;. Elle emploie près de 172&amp;nbsp;000&amp;nbsp;personnes&lt;sup&gt;&lt;a href="http://fr.wikipedia.org/wiki/Orange_(entreprise)#cite_note-orange.com-1" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;"&gt;1&lt;/a&gt;&lt;/sup&gt;, dont 105&amp;nbsp;000 en France, et sert près de 226 millions de clients dans le monde&lt;sup&gt;&lt;a href="http://fr.wikipedia.org/wiki/Orange_(entreprise)#cite_note-orange.com-1" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;"&gt;1&lt;/a&gt;&lt;/sup&gt;.&lt;/p&gt;\r\n\r\n&lt;p style="text-align:start"&gt;Orange est à l''origine une &lt;a href="http://fr.wikipedia.org/wiki/Entreprise" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="Entreprise"&gt;entreprise&lt;/a&gt; de &lt;a class="mw-redirect" href="http://fr.wikipedia.org/wiki/T%C3%A9l%C3%A9communication" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="Télécommunication"&gt;télécommunication&lt;/a&gt; d''origine &lt;a href="http://fr.wikipedia.org/wiki/Royaume-Uni" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="Royaume-Uni"&gt;britannique&lt;/a&gt; devenue, en 1999, la filiale de &lt;a href="http://fr.wikipedia.org/wiki/Mannesmann" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="Mannesmann"&gt;Mannesmann&lt;/a&gt; puis, en 2000, celle du groupe &lt;a href="http://fr.wikipedia.org/wiki/France_T%C3%A9l%C3%A9com" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="France Télécom"&gt;France Télécom&lt;/a&gt;. France Télécom, l''opérateur téléphonique historique en &lt;a href="http://fr.wikipedia.org/wiki/France" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="France"&gt;France&lt;/a&gt;, s''est internationalisé suite au rachat d''Orange. Le nouveau groupe ainsi créé est présent notamment en &lt;a href="http://fr.wikipedia.org/wiki/Europe" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="Europe"&gt;Europe&lt;/a&gt; et en &lt;a href="http://fr.wikipedia.org/wiki/Afrique" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="Afrique"&gt;Afrique&lt;/a&gt;. À partir du rachat d''Orange, la plupart des marques du groupe France Télécom sont passées sous la marque Orange. Orange depuis le &lt;a href="http://fr.wikipedia.org/wiki/1er_juillet" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="1er juillet"&gt;1&lt;sup&gt;er&lt;/sup&gt;&lt;/a&gt;&amp;nbsp;&lt;a href="http://fr.wikipedia.org/wiki/Juillet_2013" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="Juillet 2013"&gt;juillet&lt;/a&gt;&amp;nbsp;&lt;a href="http://fr.wikipedia.org/wiki/2013" style="text-decoration: none; color: rgb(11, 0, 128); background-image: none; background-position: initial initial; background-repeat: initial initial;" title="2013"&gt;2013&lt;/a&gt; est devenu le nouveau nom de France Télécom.&lt;/p&gt;', NULL, NULL, NULL, NULL, 'Boris Parato', 'Technical CEO', '5679666', 'tech@orange-fr.fr');

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `meta_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `meta_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_visible` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

INSERT INTO `category` (`id`, `name`, `slug`, `meta_title`, `meta_description`, `is_visible`) VALUES
(1, 'Art', 'art', 'Art category', 'art category description', 1),
(2, 'Painting', 'painting', 'Painting category', 'Painting category description', 0),
(3, 'Technology', 'technology', 'Technology category', 'Technology category description', 1),
(4, 'Decoration', 'decoration', 'Decoration category', 'Decoration category description', 1);

CREATE TABLE IF NOT EXISTS `category_translations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(11) DEFAULT NULL,
  `locale` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `field` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lookup_unique_idx` (`locale`,`object_id`,`field`),
  KEY `IDX_1C60F915232D562B` (`object_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

INSERT INTO `category_translations` (`id`, `object_id`, `locale`, `field`, `content`) VALUES
(1, 1, 'fr', 'name', 'Art'),
(2, 1, 'fr', 'slug', 'art'),
(3, 1, 'fr', 'metaTitle', 'Catégorie Art'),
(4, 1, 'fr', 'metaDescription', 'Catégorie art : la description'),
(5, 2, 'fr', 'name', 'Peinture'),
(6, 2, 'fr', 'slug', 'peinture'),
(7, 2, 'fr', 'metaTitle', 'Catégorie Peinture'),
(8, 2, 'fr', 'metaDescription', 'Catégorie peinture, la description'),
(9, 3, 'fr', 'name', 'Technologie'),
(10, 3, 'fr', 'slug', 'technologie'),
(11, 3, 'fr', 'metaTitle', 'Catégorie Technologie'),
(12, 3, 'fr', 'metaDescription', 'La descirption de la catégorie Technologie'),
(13, 4, 'fr', 'name', 'Déco'),
(14, 4, 'fr', 'slug', 'deco'),
(15, 4, 'fr', 'metaTitle', 'Catégorie déco'),
(16, 4, 'fr', 'metaDescription', 'Description de la catégorie Déco');

CREATE TABLE IF NOT EXISTS `entry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `is_public` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_2B219D70166D1F9C` (`project_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

INSERT INTO `entry` (`id`, `project_id`, `title`, `content`, `is_public`, `created_at`, `deleted_at`) VALUES
(1, 3, 'Hey', '&lt;p&gt;Hey what''s up ?&lt;br /&gt;\r\n&lt;br /&gt;\r\nThe project is on the road !&lt;/p&gt;', 0, '2013-09-23 11:28:39', NULL),
(2, 3, 'Full visible', '&lt;p&gt;It''s some public entry for all&lt;/p&gt;', 1, '2013-09-23 11:29:21', NULL),
(3, 3, 'Private entry', '&lt;p&gt;Restricted to &lt;strong&gt;particpants&lt;/strong&gt; only !&lt;/p&gt;', 0, '2013-09-23 11:29:56', NULL),
(4, 3, 'Private entry', '&lt;p&gt;Restricted to &lt;strong&gt;particpants&lt;/strong&gt; only !&lt;/p&gt;', 0, '2013-09-23 11:32:01', NULL),
(5, 1, 'Hey', '&lt;p&gt;YEp, we did it ! &lt;strong&gt;funding&lt;/strong&gt; phase !&lt;/p&gt;', 1, '2013-09-23 11:39:49', NULL),
(6, 1, 'Only for particpants', '&lt;p&gt;Thanks for helping me out !&lt;/p&gt;', 0, '2013-09-23 11:40:16', NULL);

CREATE TABLE IF NOT EXISTS `entry_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `is_visible` tinyint(1) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B892FDFBBA364942` (`entry_id`),
  KEY `IDX_B892FDFBA76ED395` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `ext_log_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `logged_at` datetime NOT NULL,
  `object_id` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `object_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `version` int(11) NOT NULL,
  `data` longtext COLLATE utf8_unicode_ci COMMENT '(DC2Type:array)',
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `log_class_lookup_idx` (`object_class`),
  KEY `log_date_lookup_idx` (`logged_at`),
  KEY `log_user_lookup_idx` (`username`),
  KEY `log_version_lookup_idx` (`object_id`,`object_class`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `ext_translations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `locale` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `object_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `field` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `foreign_key` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lookup_unique_idx` (`locale`,`object_class`,`field`,`foreign_key`),
  KEY `translations_lookup_idx` (`locale`,`object_class`,`foreign_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `answer` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_visible` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

INSERT INTO `faq` (`id`, `question`, `answer`, `is_visible`) VALUES
(1, '&lt;p&gt;How to pay on the &lt;strong&gt;website&lt;/strong&gt; ?&lt;/p&gt;', '&lt;p&gt;You can pay by &lt;em&gt;credit card&lt;/em&gt; or &lt;em&gt;cheque&lt;/em&gt; or &lt;em&gt;bankwire&lt;/em&gt;&lt;/p&gt;', 1),
(2, '&lt;p&gt;How to start a project ?&lt;/p&gt;', '&lt;p&gt;By going to&amp;nbsp; "Launch my project" page&lt;/p&gt;', 1),
(3, '&lt;p&gt;How to be partner ?&lt;/p&gt;', '&lt;p&gt;Be a &lt;strong&gt;partner&lt;/strong&gt; and enjoy !&lt;br /&gt;\r\n&amp;nbsp;&lt;/p&gt;', 0);

CREATE TABLE IF NOT EXISTS `faq_translations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(11) DEFAULT NULL,
  `locale` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `field` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lookup_unique_idx` (`locale`,`object_id`,`field`),
  KEY `IDX_99569DA2232D562B` (`object_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

INSERT INTO `faq_translations` (`id`, `object_id`, `locale`, `field`, `content`) VALUES
(1, 1, 'fr', 'question', '&lt;p&gt;Comment payer sur le site ?&lt;/p&gt;'),
(2, 1, 'fr', 'answer', '&lt;p&gt;Pour payer sur le site, vous pouvez utiliser votre &lt;u&gt;carte bleue&lt;/u&gt;, faire un &lt;u&gt;virement&lt;/u&gt; ou payer &lt;u&gt;par cheque&lt;/u&gt;&lt;/p&gt;'),
(3, 2, 'fr', 'question', '&lt;p&gt;Comment faire un projet ?&lt;/p&gt;'),
(4, 2, 'fr', 'answer', '&lt;p&gt;En se rendant sur la page "Lancer mon projet"&lt;/p&gt;'),
(5, 3, 'fr', 'question', '&lt;p&gt;Comment devenir partenaire ?&lt;/p&gt;'),
(6, 3, 'fr', 'answer', '&lt;p&gt;Devenir un partenaire et amusez vous !&lt;/p&gt;');

CREATE TABLE IF NOT EXISTS `page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `meta_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `meta_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `is_visible` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

INSERT INTO `page` (`id`, `title`, `meta_title`, `meta_description`, `slug`, `content`, `is_visible`) VALUES
(1, 'How does it work', 'How does it work', 'How does it work ? Some infos here', 'how-does-it-work', '&lt;p&gt;Little big Joe is a &lt;em&gt;crowdfunding&lt;/em&gt; &lt;strong&gt;website &lt;/strong&gt;&lt;br /&gt;\r\n&amp;nbsp;&lt;/p&gt;', 1),
(2, 'Contact', 'Contact', 'Contact page for Little Big Joe', 'contact-page', '&lt;p&gt;Contact page for Little Big Joe &lt;a href="http://google.fr"&gt;content &lt;/a&gt;&lt;/p&gt;', 0);

CREATE TABLE IF NOT EXISTS `page_translations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(11) DEFAULT NULL,
  `locale` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `field` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lookup_unique_idx` (`locale`,`object_id`,`field`),
  KEY `IDX_78AB76C9232D562B` (`object_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

INSERT INTO `page_translations` (`id`, `object_id`, `locale`, `field`, `content`) VALUES
(1, 1, 'fr', 'title', 'Comment ca fonctionne'),
(2, 1, 'fr', 'slug', 'comment-ca-fonctionne'),
(3, 1, 'fr', 'metaTitle', 'Comment ca fonctionne'),
(4, 1, 'fr', 'metaDescription', 'Comment ca fonctionne ? Des réponses dans cette page'),
(5, 1, 'fr', 'content', '&lt;p&gt;Little Big Joe est un &lt;em&gt;site&lt;/em&gt; de &lt;strong&gt;crowdfunding &lt;/strong&gt;&lt;/p&gt;'),
(6, 2, 'fr', 'title', 'Contact'),
(7, 2, 'fr', 'slug', 'page-de-contact'),
(8, 2, 'fr', 'metaTitle', 'Contact'),
(9, 2, 'fr', 'metaDescription', 'Page de contact pour little Big joe'),
(10, 2, 'fr', 'content', '&lt;p&gt;Page de contact de Little Big Joe &lt;a href="http://google.fr"&gt;content &lt;/a&gt;&lt;/p&gt;');

CREATE TABLE IF NOT EXISTS `project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pitch` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `language` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `amount_required` decimal(10,0) NOT NULL,
  `amount_count` decimal(10,0) DEFAULT NULL,
  `likes_required` int(11) NOT NULL,
  `likes_count` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `mangopay_wallet_id` int(11) DEFAULT NULL,
  `mangopay_created_at` datetime DEFAULT NULL,
  `mangopay_updated_at` datetime DEFAULT NULL,
  `status` int(11) NOT NULL,
  `status_updated_at` datetime DEFAULT NULL,
  `ended_at` datetime DEFAULT NULL,
  `ending_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `is_favorite` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_2FB3D0EE44F5D008` (`brand_id`),
  KEY `IDX_2FB3D0EE12469DE2` (`category_id`),
  KEY `IDX_2FB3D0EEA76ED395` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

INSERT INTO `project` (`id`, `brand_id`, `category_id`, `user_id`, `name`, `slug`, `photo`, `location`, `pitch`, `language`, `description`, `amount_required`, `amount_count`, `likes_required`, `likes_count`, `created_at`, `updated_at`, `mangopay_wallet_id`, `mangopay_created_at`, `mangopay_updated_at`, `status`, `status_updated_at`, `ended_at`, `ending_at`, `deleted_at`, `is_favorite`) VALUES
(1, 2, 3, 3, 'Refonte de l''iPhone 5s', 'refonte-de-liphone-5s', 'uploads/projects/1/3db10330cf2bb23d0eb96cf4d41d5b3efa073a70.jpg', 'Clichy', 'Je souhaiterai refondre l''iPhone 5s, pour qu''il est une plus grande autonomie !', 'fr', '&lt;p&gt;L’&lt;strong&gt;iPhone&lt;/strong&gt; 5s a été imaginé dans une optique précise. Élaboré avec un soin méticuleux.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;img alt="" src="http://dev.littlebigjoe.com/uploads/projects/1/iphone-5s-261.jpg" style="height:266px; width:400px" /&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Ciselé avec une précision extrême. Il n’est pas simplement le produit de ce qui est technologiquement possible, mais de ce qui est utile. Il n’est pas seulement une vue sur l’&lt;u&gt;avenir&lt;/u&gt;, mais une inspiration pour&amp;nbsp;l’avenir.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;a href="http://dev.littlebigjoe.com/uploads/projects/1/771c6638be8c53b551d1f7fcf276f8f3caae5875"&gt;iphone, guide de l''utilisateur.pdf&lt;/a&gt;&lt;/p&gt;', 1000, 0, 2, 2, '2013-09-23 11:13:51', '2013-09-23 11:48:35', 562647, '2013-09-23 11:13:51', '2013-09-23 11:13:51', 2, '2008-01-01 00:00:00', NULL, '2013-10-01 15:55:00', NULL, 1),
(2, 1, 1, 1, 'Make the new Air Jordan', 'make-the-new-air-jordan', NULL, 'NYC, US', 'I would like to make some wonderful air jordans shoes', 'en', '&lt;p style="text-align:start"&gt;Nike Air Jordan est une ligne &lt;strong&gt;de chaussures de basket-ball&lt;/strong&gt; de marque Nike, frappées du nom de Michael Jordan, joueur des Chicago Bulls en NBA. Les authentiques chaussures de Michael Jordan sont de la taille "47" et sont marquées "&lt;em&gt;Made in USA&lt;/em&gt;" derrière la languette, ces paires sont généralement invendables pour des raisons historiques par la &lt;a href="http://nba.com"&gt;NBA&lt;/a&gt; et par &lt;a href="http://nike.com"&gt;Nike&lt;/a&gt;.&lt;/p&gt;\r\n\r\n&lt;p style="text-align:start"&gt;&lt;img alt="" src="http://dev.littlebigjoe.com/uploads/projects/2/air-jordan-4-bred-images-officielles.jpg" style="height:135px; width:200px" /&gt;&lt;img alt="" src="http://dev.littlebigjoe.com/uploads/projects/2/air-jordan-4-retro-fire-red-cement-grey-toro-bravo-2.jpg" style="height:133px; width:200px" /&gt;&lt;/p&gt;', 50, 0, 10, 0, '2013-09-23 11:22:15', '2013-09-23 11:49:49', 562648, '2013-09-23 09:22:16', '2013-09-23 09:22:16', 1, '2008-01-01 00:00:00', NULL, '2014-12-31 23:59:00', NULL, 0),
(3, 1, 1, 3, 'Make the soundtrack of nike ads', 'make-the-soundtrack-of-nike-ads', NULL, 'Los Angeles, US', 'I would like to realize the next soundtrack for Nike''s ads', 'en', '<p>I already have realized multiple soundtracks, here''s <em>some</em>  :</p>\r\n\r\n<p><object type="application/x-shockwave-flash" data="/bundles/littlebigjoefrontend/flash/dewplayer/dewplayer-mini.swf" width="160" height="20" id="player_73e7d3f0dcce82df619abeb323026d9ac18c5d68" name="player_73e7d3f0dcce82df619abeb323026d9ac18c5d68"><param name="wmode" value="transparent" /><param name="movie" value="/bundles/littlebigjoefrontend/flash/dewplayer/dewplayer-mini.swf" /><param name="flashvars" value="showtime=1&mp3=http://dev.littlebigjoe.com/uploads/projects/3/73e7d3f0dcce82df619abeb323026d9ac18c5d68" /></object></p>\r\n\r\n<p><object type="application/x-shockwave-flash" data="/bundles/littlebigjoefrontend/flash/dewplayer/dewplayer-mini.swf" width="160" height="20" id="player_bc713aed2f5c51fc7d178bc43cfff92a70978c88" name="player_bc713aed2f5c51fc7d178bc43cfff92a70978c88"><param name="wmode" value="transparent" /><param name="movie" value="/bundles/littlebigjoefrontend/flash/dewplayer/dewplayer-mini.swf" /><param name="flashvars" value="showtime=1&mp3=http://dev.littlebigjoe.com/uploads/projects/3/bc713aed2f5c51fc7d178bc43cfff92a70978c88" /></object></p>\r\n\r\n<p>You can find <strong>them</strong> in the following pdf :</p>\r\n\r\n<p><a href="http://dev.littlebigjoe.com/uploads/projects/3/68e39b03f7554bed1d13dbdc281dc56596b600ef">dewplayer.zip</a></p>', 11000, 0, 1000, 0, '2013-09-23 11:28:04', '2013-09-23 11:28:04', 562685, '2013-09-23 09:28:04', '2013-09-23 09:28:04', 1, NULL, NULL, '2013-10-21 09:30:00', NULL, 0);

CREATE TABLE IF NOT EXISTS `project_contribution` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `project_reward_id` int(11) DEFAULT NULL,
  `mangopay_contribution_id` int(11) NOT NULL,
  `mangopay_amount` decimal(10,0) NOT NULL,
  `mangopay_is_succeeded` tinyint(1) NOT NULL,
  `mangopay_is_completed` tinyint(1) NOT NULL,
  `mangopay_error` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mangopay_answer_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mangopay_created_at` datetime NOT NULL,
  `mangopay_updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C092FA76166D1F9C` (`project_id`),
  KEY `IDX_C092FA76A76ED395` (`user_id`),
  KEY `IDX_C092FA76F55AE976` (`project_reward_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `project_like` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_95F288AB166D1F9C` (`project_id`),
  KEY `IDX_95F288ABA76ED395` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

INSERT INTO `project_like` (`id`, `project_id`, `user_id`, `created_at`) VALUES
(1, 1, 3, '2013-09-23 11:37:29'),
(2, 1, 1, '2013-09-23 11:38:47');

CREATE TABLE IF NOT EXISTS `project_reward` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `amount` decimal(10,0) NOT NULL,
  `stock` int(11) NOT NULL,
  `max_quantity_by_user` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_59759919166D1F9C` (`project_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

INSERT INTO `project_reward` (`id`, `project_id`, `title`, `description`, `amount`, `stock`, `max_quantity_by_user`) VALUES
(1, 1, '100 €', 'Si vous payez 100 € je vous offre une coque en or !', 100, 10, 1),
(2, 1, '1000 €', 'Si vous payez 1000 € je vous offre l''iPhone restylisé !', 1000, 1, 1),
(3, 1, '50 €, la récompense la plus basse', 'Pour 50 €, je peux vous envoyer un film protecteur', 50, 100, 10),
(4, 2, '100 €', '100 € and you''ll get free shoes', 100, 20, 1),
(5, 3, '500 €', 'The top of the top reward :  I will make you some wedding sound', 500, 1, 1),
(6, 3, '250 €', 'You''ll get a free ringtone', 250, 30, 3);

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username_canonical` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email_canonical` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `salt` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `locked` tinyint(1) NOT NULL,
  `expired` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  `confirmation_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_requested_at` datetime DEFAULT NULL,
  `roles` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT '(DC2Type:array)',
  `credentials_expired` tinyint(1) NOT NULL,
  `credentials_expire_at` datetime DEFAULT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `birthday` datetime NOT NULL,
  `facebook_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `facebook_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter_access_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `google_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nationality` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `default_language` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bio` longtext COLLATE utf8_unicode_ci,
  `ip_address` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `person_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `mangopay_user_id` int(11) NOT NULL,
  `mangopay_created_at` datetime NOT NULL,
  `mangopay_updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D64992FC23A8` (`username_canonical`),
  UNIQUE KEY `UNIQ_8D93D649A0D96FBF` (`email_canonical`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

INSERT INTO `user` (`id`, `username`, `username_canonical`, `email`, `email_canonical`, `enabled`, `salt`, `password`, `last_login`, `locked`, `expired`, `expires_at`, `confirmation_token`, `password_requested_at`, `roles`, `credentials_expired`, `credentials_expire_at`, `firstname`, `lastname`, `birthday`, `facebook_id`, `facebook_url`, `twitter_id`, `twitter_access_token`, `twitter_url`, `google_url`, `website_url`, `city`, `country`, `nationality`, `default_language`, `photo`, `bio`, `ip_address`, `person_type`, `mangopay_user_id`, `mangopay_created_at`, `mangopay_updated_at`) VALUES
(1, 'admin@littlebigjoe.com', 'admin@littlebigjoe.com', 'admin@littlebigjoe.com', 'admin@littlebigjoe.com', 1, 'ewbe1cdcqxskw0os4g08kw8ogko0sss', 'JsoaTYOl/uqouNmO0wjxyccVUtaxEMxTSNb2Y/FWx9oYcbBaoNRHGKDl/rLs3MKV5eCwYt6piYaoLvMWyQPtbA==', '2013-09-23 11:33:16', 0, 0, NULL, NULL, NULL, 'a:2:{i:0;s:9:"ROLE_USER";i:1;s:10:"ROLE_ADMIN";}', 0, NULL, 'Admin', 'LittleBigJoe', '2013-09-23 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Paris', 'FR', 'French', 'fr', NULL, 'Admin account', '127.0.0.1', 'NATURAL_PERSON', 0, '2013-09-23 09:28:15', '2013-09-23 09:28:15'),
(2, 'pierrick@adentify.com', 'pierrick@adentify.com', 'pierrick@adentify.com', 'pierrick@adentify.com', 1, 'l4g83ehou684kwgss4ckc0skogog0gk', 'kS0VVOLNYUkCifMJYSHW+5oD2+WtdCPUMTcDd1o1L9+NYMxxlOnar+SKwdDiKAiV/83Vear7+42jIoU2neyGpw==', '2013-09-23 09:41:29', 0, 0, NULL, NULL, NULL, 'a:2:{i:0;s:9:"ROLE_USER";i:1;s:10:"ROLE_ADMIN";}', 0, NULL, 'Pierrick', 'Martos', '2013-09-23 00:00:00', NULL, 'https://www.facebook.com/pierrick.martos‎', NULL, NULL, 'https://twitter.com/PierrickMartos‎', NULL, NULL, 'Paris', 'FR', 'French', 'fr', 'uploads/users/54f7b249c49cbb1000140a004fea52d095259235.jpg', 'Pierrick martos account', '127.0.0.1', 'NATURAL_PERSON', 560670, '2013-09-23 07:30:48', '2013-09-23 07:30:48'),
(3, 'laurentbrieu@gmail.com', 'laurentbrieu@gmail.com', 'laurentbrieu@gmail.com', 'laurentbrieu@gmail.com', 1, 'gehp8vm3ic8cks0c8w8k4c4go0004ko', 'gA4WcndbnK4WQrbDPUkMCvIDVMixI0qmPnNuxWPO3XSC6QkW+7vl+EmHmdkD7/SccRG4qDlheoRb8eEvIzM6Bw==', '2013-09-23 11:17:13', 0, 0, NULL, NULL, NULL, 'a:1:{i:0;s:9:"ROLE_USER";}', 0, NULL, 'Laurent', 'Brieu', '1988-02-16 00:00:00', NULL, 'https://fr-fr.facebook.com/LaurentBrieu', NULL, NULL, 'https://twitter.com/LaurentBrieu‎', 'https://plus.google.com/10518081515894608113', 'http://www.laurentbrieu.com', 'Cergy', 'FR', 'French', 'en', 'uploads/users/02775ce1232440c7cb753f920413bbd99c9061c8.jpg', 'Laurent brieu private bio', '127.0.0.1', 'NATURAL_PERSON', 560679, '2013-09-23 07:55:03', '2013-09-23 07:55:03');


ALTER TABLE `category_translations`
  ADD CONSTRAINT `FK_1C60F915232D562B` FOREIGN KEY (`object_id`) REFERENCES `category` (`id`) ON DELETE CASCADE;

ALTER TABLE `entry`
  ADD CONSTRAINT `FK_2B219D70166D1F9C` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`);

ALTER TABLE `entry_comment`
  ADD CONSTRAINT `FK_B892FDFBA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `FK_B892FDFBBA364942` FOREIGN KEY (`entry_id`) REFERENCES `entry` (`id`);

ALTER TABLE `faq_translations`
  ADD CONSTRAINT `FK_99569DA2232D562B` FOREIGN KEY (`object_id`) REFERENCES `faq` (`id`) ON DELETE CASCADE;

ALTER TABLE `page_translations`
  ADD CONSTRAINT `FK_78AB76C9232D562B` FOREIGN KEY (`object_id`) REFERENCES `page` (`id`) ON DELETE CASCADE;

ALTER TABLE `project`
  ADD CONSTRAINT `FK_2FB3D0EEA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `FK_2FB3D0EE12469DE2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  ADD CONSTRAINT `FK_2FB3D0EE44F5D008` FOREIGN KEY (`brand_id`) REFERENCES `brand` (`id`);

ALTER TABLE `project_contribution`
  ADD CONSTRAINT `FK_C092FA76F55AE976` FOREIGN KEY (`project_reward_id`) REFERENCES `project_reward` (`id`),
  ADD CONSTRAINT `FK_C092FA76166D1F9C` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`),
  ADD CONSTRAINT `FK_C092FA76A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

ALTER TABLE `project_like`
  ADD CONSTRAINT `FK_95F288ABA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `FK_95F288AB166D1F9C` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`);

ALTER TABLE `project_reward`
  ADD CONSTRAINT `FK_59759919166D1F9C` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`);
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
